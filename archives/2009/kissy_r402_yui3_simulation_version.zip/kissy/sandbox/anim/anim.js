/**
 * @module anim
 */
KISSY.add("anim", null, undefined, {
    submodules: ["anim-base", "anim-easing"]
});
