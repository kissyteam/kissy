orderOfEvents.bodyEndLargeExternalScriptTime = [new Date, "[body end] normal external script run time"];
