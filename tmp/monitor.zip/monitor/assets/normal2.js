orderOfEvents.bodyLargeExternalScriptTime = [new Date, "[body] normal external script run time"];
